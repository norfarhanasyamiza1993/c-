﻿using System;

namespace Console_Project1
{
    class Program
    {
   

        //insert 2 input value....show result ADD two number
        public int summation(int x, int y)
        {
            int result;
            result = x + y;
            return result;
        }

        public int AcceptValues()
        {
            Console.Write("Enter The Number: ");
            int  v1 = Convert.ToInt32(Console.ReadLine());
            return v1;
        }

        public String DisplayResult(String res)
        {
            Console.WriteLine("Summation of the number is:" + res);
            return res;
        }


        /*Main function Call*/
        static void Main(string[] args)
        {
            Program n = new Program();
            /*received 2 number--same input,call same function*/   
            int value1=n.AcceptValues();     
            int value2 = n.AcceptValues();

            /*call summation function*/
            int result = n.summation(value1, value2);

            /*display result of summation*/
            n.DisplayResult(result.ToString());          

            Console.ReadKey();

        }
    }
}


