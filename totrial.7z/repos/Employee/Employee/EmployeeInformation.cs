﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*A.class can reused code
 * 1.create project-->choose c#-->class library
 2.class1.cs--> auto created
 3.manually create-----Employee--add--class---'create own class'*/

/*B.namespace to organize the code
 */

/*C.class level-->Employee-->add-->newFolder(hr)
 * hr--->add-->class-->Account/// new namespace(master namespace.new folder(hr))
*/


namespace Employee
{
    public class EmployeeInformation
    {
        string fName;
        string lName;
        string add;
        string id;
        string phoneNumber;

        HumanResource.Account a;

        //add auto properties-->set/get;
        //add data encapsulation

        /*D.set-can set
         get- can get everyting as long is true with auto properties*/

        /*E.assign Acces modifier to acces it and assign limit
         public/private/prtected and internal*/


      
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string address { get; set; }
        public string staffId { get; set; }
        public string phoneNum { get; set; }

        private string twitterAdd;

        public string twitterAddressPaten
        {
            //make sure the twitter address start with @
            get { return twitterAdd; }
            set
            {
                if (value.StartsWith("A"))
                {
                    twitterAdd = value;
                }
                else
                {
                    throw new Exception("Twitter id must begin with A");
                }
            }
        }
        /*F.constructor-name must same with class name,
         * cannot have void/return type*/
        public EmployeeInformation(){

        }

    }
}
