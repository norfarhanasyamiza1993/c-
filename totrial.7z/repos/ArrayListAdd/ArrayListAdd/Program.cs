﻿using System;
using System.Collections;//array list menthod
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayListAdd
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList Student = new ArrayList();

            Student.Add("nor");
            Student.Add("farhana");
            Student.Add("syamiza");
            Student.Add(123456789);

            //
            Science a = new Science();
            a.id = 10990;
            a.name = "fasha";
            a.phoneNumber = "012-8091300";

            Student.Add(a);

            foreach (object i in Student)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
class Science
{
    public int id { get; set; }
    public string name { get; set; }
    public string phoneNumber { get; set; }

    public override string ToString()
    {
        return id +"\t"+ name+"\t"+ phoneNumber;
    }

}