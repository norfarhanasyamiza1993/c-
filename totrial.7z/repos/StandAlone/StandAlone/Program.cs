﻿/*insert a person details,display the person details with the status of age of the person*/
using System;
namespace StandAlone
{
    class Program
    {
        //statement-Age Development
        public String AgeDevelopmentStatus(int age)
        {
            String status;
            if(age <= 2)            {
                status = "Pre-Natal";
            }else if(age>2 && age <= 16)
            {
                status = "Chilhood";
            }else if (age >= 17 && age <= 29)
            {
                status = "Adolescence";
            }
            else if (age >= 30 && age <= 49)
            {
                status = "Adult-Hood";
            }
            else
            {
                status = "Old-Age";
            }
            return status;
        }
        

        //input-name,age and weight,
        public string AcceptName(){
            string name;        
            Console.Write("Enter name:");
            name = Console.ReadLine();
            return name;
        }
        public int AcceptAge()
        {
            int age;
            Console.Write("Enter Age:");
            age = Convert.ToInt32(Console.ReadLine());
            return age;
        }
        public Double AcceptWeight()
        {
            double weight;
            Console.Write("Enter Weight:");
            weight = Convert.ToDouble(Console.ReadLine());
            return weight;
        }

        //output-dislay 
        public void DisplayResult(string name,int age,double weight, string status)
            {
                Console.WriteLine("Your Name:",name);
                Console.WriteLine("Your Age:",age.ToString());
                Console.WriteLine("Your Weight:",weight.ToString());
                Console.WriteLine("Age Stage Development:",status);

            }
        static void Main(string[] args)
        {
            Program obj = new Program();
            string name=obj.AcceptName();
            int age = obj.AcceptAge();
            Double weight = obj.AcceptWeight();
            string status =obj.AgeDevelopmentStatus(age);

            Console.WriteLine("----------------------");
            Console.WriteLine("Name:" + name);
            Console.WriteLine("Name:" + age);
            Console.WriteLine("Name:" + weight);
            Console.WriteLine("Age Stage Development 123:"+status);
            Console.WriteLine("-------------Called result function---------");
            obj.DisplayResult(name,age,weight,status);
            Console.ReadLine();
        }
    
    }
}
