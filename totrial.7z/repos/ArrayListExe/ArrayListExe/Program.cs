﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//aray is strongly type; declare integer,value must be integer
// store different data types in the array, by create an array of type object



namespace ArrayListExe
{
    class Program
    {
        void Display(object[] arrayname)
        {
            foreach (object i in arrayname)
            {
                Console.WriteLine(i);
            }

        }
        void InputArray(object[] varArray)
        {
            for(int i = 0; i < varArray.Length; i++)
            {
                //create object of the class---buka class dibawah
                Student obj = new Student();
                Console.Write("Enter ID:");
                obj.id = Console.ReadLine();
                Console.Write("Enter Name:");
                obj.name = Console.ReadLine();
                Console.Write("Enter Address:");
                obj.address = Console.ReadLine();

                varArray[i] = obj;

                //buka class inherit dari page lain
                //Customer ob = new Customer();
                //ob.id = 123;
                //ob.name = "implement new class----learning c#";
                //varArray[2] = ob;

            }

        }


        static void Main(string[] args)
        {
            Program m = new Program();
            //create object type of array
            object[] array = new object[4];
            m.InputArray(array);            
            m.Display(array);

           
            //display data in array-new class ,only display the class name
            
            //foreach (object obj in array)
            //{
            //    //print values of the items that we have in array    
            //    Console.WriteLine(obj);
            //}
            Console.ReadKey();

            /*int[] array = new int[2];
            array[0] = "hanan";
            Console.ReadKey();*/
        }
    }

}
class Student
{
    public string id { get; set; }
    public string name { get; set; }
    public string address { get; set; }

    //override the ToString method for meaningfull output 
    public override string ToString()
    {
        //get name of the customer by Name property    
        return "id:"+this.id+"\nname:"+this.name+"\naddress:"+this.address;
    }
 


}


//using System;    
//using System.Collections.Generic;    
//using System.Linq;    
//using System.Text;    

//namespace ArrayListExe
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            object[] array = new object[3];
//            array[0] = 1;
//            array[1] = "string";

//            customer c = new customer();
//            c.ID = 1;
//            c.Name = "C# corner";
//            array[2] = c;

//            foreach (object obj in array)
//            {
//                //print values of the items that we have in array    
//                Console.WriteLine(obj);
//            }
//            Console.ReadKey();

//        }
//    }
//}
//class customer
//{
//    public int ID { get; set; }
//    public string Name { get; set; }
//}