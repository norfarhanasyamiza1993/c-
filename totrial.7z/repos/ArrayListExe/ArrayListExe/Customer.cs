﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*example if a class "customer" includes the two properties ID and Name and we increase the size of the array by 3 
* sthen create an instance of the customer class and by using the properties store values,
* I can even store the complex type as in the following code.*/

namespace ArrayListExe
{
    class Customer
    {
        internal int id;

        public string name { get; internal set; }
    }
}
