﻿
using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

           
        }
        //button event function
        private void AddButton(object sender, EventArgs e)
        {         
            int numberOne = AcceptFirstValue();
            int numberTwo = AcceptSecondValue();
            int resultAdd = AddNumbers(numberOne, numberTwo);
            DisplayResult(resultAdd.ToString());           
        }

        private void SubtractButton(object sender, EventArgs e)
        {
            int numberOne = AcceptFirstValue();
            int numberTwo = AcceptSecondValue();
            int resultSub = SubtractNumbers(numberOne, numberTwo);
            DisplayResult(resultSub.ToString());
        }

        private void MultipleButton(object sender, EventArgs e)
        {
            int numberOne = AcceptFirstValue();
            int numberTwo = AcceptSecondValue();
            int resultMul = MultipleNumbers(numberOne, numberTwo);
            DisplayResult(resultMul.ToString());
        }

        private void DevideButton(object sender, EventArgs e)
        {
            int numberOne = AcceptFirstValue();
            int numberTwo = AcceptSecondValue();
            double resultDiv = DivideNumbers(numberOne, numberTwo);
            DisplayResult(resultDiv.ToString());
        }


        //received input:
        public int AcceptFirstValue()
        {
            int numberOne = Convert.ToInt32(txtInputValue1.Text);
            return numberOne;
        }
        public int AcceptSecondValue()
        {
            int numberTwo = Convert.ToInt32(txtInputValue2.Text);
            return numberTwo;
        }

        //output
        public string DisplayResult(string res)
        {            
            result.Text=res;
            return res;
        }




        //operation
        public int AddNumbers(int number1, int number2)
        {
            int addResult = number1 + number2;
            return addResult;
        }

        public int SubtractNumbers(int number1, int number2)
        {
            int subResult = number1 - number2;
            return subResult;
        }
        public int MultipleNumbers(int number1, int number2)
        {
            int mulResult = number1 * number2;
            return mulResult;
        }
        public double DivideNumbers(double number1, double number2)
        {
            double mulResult = number1 / number2;
            return mulResult;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}