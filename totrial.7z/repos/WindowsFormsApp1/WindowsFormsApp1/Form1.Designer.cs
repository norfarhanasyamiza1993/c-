﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInput1 = new System.Windows.Forms.Label();
            this.txtInputValue1 = new System.Windows.Forms.TextBox();
            this.add = new System.Windows.Forms.Button();
            this.txtInputValue2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.mul = new System.Windows.Forms.Button();
            this.sub = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblInput1
            // 
            this.lblInput1.AutoSize = true;
            this.lblInput1.Location = new System.Drawing.Point(130, 110);
            this.lblInput1.Name = "lblInput1";
            this.lblInput1.Size = new System.Drawing.Size(95, 17);
            this.lblInput1.TabIndex = 0;
            this.lblInput1.Text = "Input Value 1:";
            // 
            // txtInputValue1
            // 
            this.txtInputValue1.Location = new System.Drawing.Point(246, 110);
            this.txtInputValue1.Name = "txtInputValue1";
            this.txtInputValue1.Size = new System.Drawing.Size(115, 22);
            this.txtInputValue1.TabIndex = 1;
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(129, 177);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(95, 40);
            this.add.TabIndex = 2;
            this.add.Text = "Add";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.AddButton);
            // 
            // txtInputValue2
            // 
            this.txtInputValue2.Location = new System.Drawing.Point(496, 110);
            this.txtInputValue2.Name = "txtInputValue2";
            this.txtInputValue2.Size = new System.Drawing.Size(115, 22);
            this.txtInputValue2.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(380, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Input Value 2:";
            // 
            // mul
            // 
            this.mul.Location = new System.Drawing.Point(380, 177);
            this.mul.Name = "mul";
            this.mul.Size = new System.Drawing.Size(95, 40);
            this.mul.TabIndex = 5;
            this.mul.Text = "Multiple";
            this.mul.UseVisualStyleBackColor = true;
            this.mul.Click += new System.EventHandler(this.MultipleButton);
            // 
            // sub
            // 
            this.sub.Location = new System.Drawing.Point(246, 177);
            this.sub.Name = "sub";
            this.sub.Size = new System.Drawing.Size(95, 40);
            this.sub.TabIndex = 6;
            this.sub.Text = "Subtract";
            this.sub.UseVisualStyleBackColor = true;
            this.sub.Click += new System.EventHandler(this.SubtractButton);
            // 
            // div
            // 
            this.div.Location = new System.Drawing.Point(516, 177);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(95, 40);
            this.div.TabIndex = 7;
            this.div.Text = "Devide";
            this.div.UseVisualStyleBackColor = true;
            this.div.Click += new System.EventHandler(this.DevideButton);
            // 
            // result
            // 
            this.result.BackColor = System.Drawing.SystemColors.Control;
            this.result.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result.Location = new System.Drawing.Point(344, 277);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(131, 35);
            this.result.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(255, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Result:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.result);
            this.Controls.Add(this.div);
            this.Controls.Add(this.sub);
            this.Controls.Add(this.mul);
            this.Controls.Add(this.txtInputValue2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.add);
            this.Controls.Add(this.txtInputValue1);
            this.Controls.Add(this.lblInput1);
            this.Name = "Form1";
            this.Text = "My Application";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInput1;
        private System.Windows.Forms.TextBox txtInputValue1;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox txtInputValue2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button mul;
        private System.Windows.Forms.Button sub;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.Label label2;
    }
}

