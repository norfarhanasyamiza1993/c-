﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//1.store element in array
namespace ArrayExe1
{
    class Program
    {
        //declare array
        void ReadArray(int[] arr, int size)
        {        
            //insert number into array
            for (int i = 0; i < size; i++)
            {
                Console.Write("Insert number:");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        void DisplayArray(int[] arr, int size)
        {
            Console.Write("\nElements in array are: ");
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("{0}  ", arr[i]);
            }
        }
        double AverageArray(int[] arr,int size)
        {
            double avg;
            int sum=0;
            for(int i = 0; i < size; i++)
            {
                sum = sum + arr[i];
            }
            avg = sum / 10;
            return avg;
        }

        void ReverseArray(int[] arr, int size)
        {
            for (int i = size - 1; i >= 0; i--)
            {
                Console.WriteLine("reverse array:"+ arr[i]);
            }
        }

        void DisplayResult(String res)
        {
            Console.WriteLine("Average:" + res);
        }

        static void Main(string[] args)
        {
            Program a = new Program();
            int[] arr = new int[10];
            a.ReadArray(arr,10);
            a.DisplayArray(arr,10);
            a.ReverseArray(arr, 10);
            double res = a.AverageArray(arr, 10);
            a.DisplayResult(res.ToString());         
            Console.ReadKey();
        }
    }
}
