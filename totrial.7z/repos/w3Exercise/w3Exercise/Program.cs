﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace w3Exercise
{
    class Program
    {
        void Display()
        {
            Console.WriteLine("Hello");
            Console.WriteLine("Norfarhana Syamiza");
        }
        int  Input()
        {
            Console.Write("enter number:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            return num1;
        }

        int summation(int x,int y)
        {
            int result = x + y;
            return result;
        }

        void SwapNumber(int x,int y)
        {
            int temp = x;
            x = y;
            y = temp;

            SwapResult(x, y);           
 
        }
        void SwapResult(int x,int y)
        {
            Console.Write("\nAfter Swapping : ");
            Console.Write("\nFirst Number : " + x.ToString());
            Console.WriteLine("\nSecond Number : " + y.ToString());

        }
        void MultipleTable(int num)
        {
            for(int i = 0; i <= 10; i++)
            {
                int result = num * i;
                Console.WriteLine("5 * " + i + "="+ result.ToString());
             //   Console.Write();
            }
        }
        double Average(int a,int b,int c,int d)
        {
            Double result = (a + b + c + d) / 4;
            return result;
        }      

        
        void Output(string res)
        {
            Console.WriteLine("Output:"+res);
        }
        static void Main(string[] args)


        {
            Program obj = new Program();
            obj.Display();
            int input1 = obj.Input();
            int input2 = obj.Input();
            int input3 = obj.Input();
            int input4 = obj.Input();
            obj.SwapNumber(input1, input2);
            obj.MultipleTable(input1);
            //int result=obj.summation(input1, input2);
            double result = obj.Average(input1, input2,input3,input4);
            obj.Output(result.ToString());
            Console.ReadKey();
        }
    }
}
